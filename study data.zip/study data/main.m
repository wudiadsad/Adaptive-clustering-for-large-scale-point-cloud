clc;
clear;
close all;
%% 加载点云
% ptCloud_in = pcread('bunny.pcd');
%指定LAS文件路径
path = "3.las";
%创建lasFileReader对象以访问LAZ文件数据。
lasReader = lasFileReader(path);
%使用readPointCloud函数从LAZ文件读取点云数据。
ptCloud_in = readPointCloud(lasReader);
%% 向量计算方法1 曲率
% 读取点云
ptCloud = readPointCloud(lasReader);
% 读取xyz
a = ptCloud.Location;
%vec储存法向量
vec = zeros(size(a));
%q储存曲率
q = zeros(length(a),1);
k = 8;
% 搜索每个点的最邻近点
neighbors = knnsearch(a(:,1:3),a(:,1:3), 'k', k+1);
for i = 1:length(a)
    curtemp = neighbors(i,2:end);
    indpoint = a(curtemp,:);
    % 计算协方差并提取特征
    [v11, c] = eig(cov(indpoint));
    %特征值按照升序排列1<2<3
    c = diag(c)';
    %计算特征值的总和
    z = sum(c);
    %计算曲率，用最小特征值除/特征值总和，这也是特征归一化
    p1 = c(:,1)/z;
    q(i,:) = abs(p1);
    %最小特征值对应的列向量就是法向量，dot是交叉相乘
    vec(i,:) = v11(:,1)';
end
% 读取x
x = ptCloud.Location(1:end,1);
% 读取y
y = ptCloud.Location(1:end,2);
% 读取z
z = ptCloud.Location(1:end,3);
% uvw为法向量的三列
u = vec(1:end,1);
v = vec(1:end,2);
w = vec(1:end,3);
u=abs(u);v=abs(v);w=abs(w);
figure(1)
pcshow(ptCloud)
hold on
% 显示法向量
quiver3(x,y,z,u,v,w);
hold off
position=[x,y,z,u,v,w];
data=[x,y,z];
%% 计算平均密度
sumdis = 0;
for i=1:length(data)    
    p_cur = data(i,:);
    [index, distance] = findNearestNeighbors(ptCloud,p_cur,2);  %寻找当前点最近的非自身点
    sumdis = sumdis + distance(2); %距离求和
end
density = sumdis / length(data);
%% 按密度排序
for i=1:length(data)    
    p_cur = data(i,:);
    [index, distance] = findNeighborsInRadius(ptCloud,p_cur,4*density);
    num=size(index,1);
    position(i,7)=num;
end
position=sortrows(position,-7);
ppt=[];
for i=1:size(position,1)
    p=position(i,:);
    if p(1,7)<=29
        break
    else
        ppt=[ppt;p];
    end
end
position11=setdiff(position,ppt,'rows');
position=position(:,1:6);
% figure
% scatter3(position11(:,1),position11(:,2),position11(:,3),'blue','+')
% hold on
% scatter3(ppt(:,1),ppt(:,2),ppt(:,3),'red','filled')
% hold off
%% 任选一点作为聚类中心
num=size(x,1);
l=0;%l确定第几个聚类
JL={};%聚类结果
mm=0;
aa=[];%存本次聚类距离
while true%换起始点作为新聚类
    P=[];%存本次聚类结果
    l=l+1;%创建多个数组,l表示第l个聚类结果
    if size(position,1)==0%非空一直运行
        break
    end
    z=0;%用来确定是不是第一次循环
    while true%多次循环直到没有新增点
        z=z+1;
        ptCloud_in=pointCloud(position(:,1:3));
        if z==1
            ap=position(1,:);%ap作为聚类中心
        else
            ap=P(end,:);
%             if size(position,1)<2
%                 ap=position;
%                 break
%             end
            if cc==ap
                break
            end
        end
        P=[P;ap];
        k=40;%取40个邻近点
        [indices,dists]=findNearestNeighbors(ptCloud_in,ap(1:3),k);
        dist=[];
        for i=1:size(dists,1)
            if dists(i)<=4*density%%后续距离改这里，改成平均密度4倍
                d=dists(i);
                dist=[dist;d];
            end
        end

        if z==1
            if size(dist,1)==1
                P=[P;ap];
                position=setdiff(position,ap,'rows');
                break
            end
        else
            if size(dist,1)==0%如果没有新增点聚类结束
                P=[P;ap];
                position=setdiff(position,ap,'rows');
                break
            end
        end
        %聚类中心的法向量
        z1=ap(1,3);
        u1=ap(1,4);
        v1=ap(1,5);
        w1=ap(1,6);
%         %% 1
%         figure(2)
%         scatter3(position(:,1),position(:,2),position(:,3),'black')
%         hold on
%         scatter3(ap(1,1),ap(1,2),ap(1,3),'green');
%         hold on
%         %% 1
        P=[P;ap(1,:)];
        P=unique(P,"rows");
        for i=1:size(dist,1)
            m=indices(i);
            if dist(i)==0%dist为0表示是自身
                continue
            end
            if m>size(position,1)
                continue
            end
            z2=position(m,3);
            u2=position(m,4);
            v2=position(m,5);
            w2=position(m,6);
            theta=(u1*u2+v1*v2+w1*w2)/(sqrt(u1^2+v1^2+w1^2))*sqrt(u2^2+v2^2+w2^2);
            theta=acos(theta);
            theta=rad2deg(theta);
            if theta>90
                theta=180-theta;
            end
            p1=P(:,3);
            p2=[p1;z2];
            ave1=sum(p1)/size(p1,1);
            ave2=sum(p2)/size(p2,1);
            sum11=0;sum22=0;
            for ll=1:size(p1,1)
                aaaa=p1(ll)-ave1;
                sum11=sum11+aaaa^2;
            end
            for ll=1:size(p2,1)
                aaaa=p2(ll)-ave2;
                sum22=sum22+aaaa^2;
            end
            a1=sqrt(sum11/size(p1,1));
            a2=sqrt(sum22/size(p2,1));
            bh=abs(a1-a2);
            %% 散乱系数
            if bh>0.1
                continue
            end
            cluster_distance=2*density*dist(i)/((theta)*abs(z1-z2));%%距离改这里,这里公式有待优化
            %如果距离小于阈值将它们归为一类
            if dist(i)<=cluster_distance
                h=indices(i);
                P=[P;position(h,:)];
            end
            aa=[aa;cluster_distance];
%             %% 2
%             scatter3(position(m,1),position(m,2),position(m,3),'red');
%             hold on
%             scatter3(P(:,1),P(:,2),P(:,3),'blue');
% %% 2
        end
        %去除已经聚类的点
        position=setdiff(position,P,'rows');
        cc=ap;
    end
    P=unique(P,"rows");
    JL{l}=P;
end
%% 绘制分类后点云
figure(3)
% scatter3(ptCloud.Location(:,1),ptCloud.Location(:,2),ptCloud.Location(:,3),'black')
% hold on
center=[];
for i=1:size(JL,2)
    pp=JL{i};
    scatter3(pp(:,1),pp(:,2),pp(:,3))
    hold on
end
hold off
%% 新增


figure(62)
% scatter3(ptCloud.Location(:,1),ptCloud.Location(:,2),ptCloud.Location(:,3),'black')
% hold on
center=[];
for i=1:size(JL,2)
    pp=JL{i};
    if size(pp,1)>20
        scatter3(pp(:,1),pp(:,2),pp(:,3))
        hold on
    end
end
hold off


%% 绘制三维包围盒观察关系
figure
sum=0;
for i=1:size(JL,2)
    pp=JL{i};
    mmm=size(pp,1);
    sum=sum+mmm;
    pp=double(pp);
    if size(pp,1)<=20
        continue
    end
    scatter3(pp(:,1),pp(:,2),pp(:,3))
    hold on
    k=boundary(pp(:,1),pp(:,2),pp(:,3),0);
    trisurf(k,pp(:,1),pp(:,2),pp(:,3),'FaceColor','red','FaceAlpha',0.1)
    hold on
end
hold off
%% 把聚类数量不足的分出来
jl1=0;%足量
jl2=0;%不足散点
for i=1:size(JL,2)
    if size(JL{i},1)<4
        jl2=jl2+1;
        JL2{jl2}=JL{i};
    else
        jl1=jl1+1;
        JL1{jl1}=double(JL{i});
    end
end
%% 用冒泡算法对数组按个数大小排序
for i=1:size(JL1,2)-1
    for j=i+1:size(JL1,2)
        s11=JL1{i};
        s1=size(s11,1);
        s22=JL1{j};
        s2=size(s22,1);
        if s1<s2
            t1=JL1{i};
            JL1{i}=JL1{j};
            JL1{j}=t1;
        end
    end
end
%% 对JL1判断是否重叠
i=0;
qgd=[];
% num=0;
while true
    position1=[];
    i=i+1;
    if i>size(JL1,2)-1
        break
    end
    p1=JL1{i};%p1大包围盒
    if size(p1,1)==0
        continue
    end
    boundary1=boundary(p1(:,1),p1(:,2));
    for k=1:size(boundary1,1)-1
        bw1=boundary1(k);%包围位于坐标第几行
        position1=[position1;p1(bw1,:)];%提取外包围坐标
    end
    poly1=polyshape(position1(:,1),position1(:,2));
    j=i;
    while true
        position2=[];
        j=j+1;
        if j>size(JL1,2)
%             RJL{i}=p1;
            break
        end
        p2=JL1{j};
        if size(p2,1)==0||j==i
            continue
        end
        boundary2=boundary(p2(:,1),p2(:,2));
        for k=1:size(boundary2,1)
            bw2=boundary2(k);
            position2=[position2;p2(bw2,:)];
        end
        %% 修改
        if size(position2,1)==0
            qgd=[qgd;p2];
            JL1{j}=[];
            continue
        end
        %% 找到重叠部分高差
        distacne1=pdist2(p1(:,1:2),p2(:,1:2));
        if min(min(distacne1))<=1.5*density
            [a,b]=find(distacne1<=1.5*density);
        else
            continue
        end
        pp1=p1(a,:);
        pp2=p2(b,:);
        poly2=polyshape(position2(:,1),position2(:,2));
        max1=max(pp1(:,3));max2=max(pp2(:,3));
        min1=min(pp1(:,3));min2=min(pp2(:,3));
        %% 判断重叠部分高差是否超过阈值
        if min2>max1&&abs(max1-min2)>0.5
            mmm=-1;
        elseif min1>max2&&abs(min1-max2)>0.5
            mmm=-1;
        else
            mmm=1;
        end
        distance=pdist2(p1(:,1:2),p2(:,1:2));
        %% 距离阈值修改
        if intersect(poly1,poly2).NumRegions>0&&mmm>0%存在重叠且距离相差不大,将两个数组叠加,重新计算外包围盒
            mmm=-1;
            p1=[p1;p2];
            p1=unique(p1,'rows');
            boundary1=[];
            boundary1=boundary(p1(:,1),p1(:,2));
            position1=[];
            for k=1:size(boundary1,1)
                bw1=boundary1(k);
                position1=[position1;p1(bw1,:)];
            end
            poly1=polyshape(position1(:,1),position1(:,2));
            JL1{i}=p1;
            JL1{j}=[];
            j=1;
            continue
        end
        %% 高程阈值
        [heng,shu]=find(distance<2);%距离小于一定距离的的两个点对位置
        hc=min(abs(p1(heng,3)-p2(shu,3)));
        if hc<0.3%%5.las用0.2
            mmm=-1;
            p1=[p1;p2];
            p1=unique(p1,'rows');
            boundary1=[];
            boundary1=boundary(p1(:,1),p1(:,2));
            position1=[];
            for k=1:size(boundary1,1)
                bw1=boundary1(k);
                position1=[position1;p1(bw1,:)];
            end
            poly1=polyshape(position1(:,1),position1(:,2));
            JL1{j}=[];
            JL1{i}=p1;
            j=0;
        end
        figure(4)
        plot(position1(:,1),position1(:,2),'r')
        hold on
        plot(position2(:,1),position2(:,2))
        hold off
    end
    if i==size(JL1,2)-1
        break
    end
end
j=0;
for i=1:size(JL1,2)
    m=JL1{i};
    if size(m,1)==0
        continue
    else
        j=j+1;
        RJL{j}=JL1{i};
    end
end
figure(5)
for i=1:size(RJL,2)
    po=RJL{i};
    k=boundary(po(:,1),po(:,2));
    plot(po(k,1),po(k,2))
    hold on
end
hold off
figure
for i=1:size(RJL,2)
    po=RJL{i};
    scatter3(po(:,1),po(:,2),po(:,3))
    hold on
end
for i=1:size(JL2,2)
    po=JL2{i};
    scatter3(po(:,1),po(:,2),po(:,3))
    hold on
end
hold off
%% 将JL2中散点取出
sd=[];
sd=[sd;qgd];
for i=1:size(JL2,2)
    sd1=JL2{i};
    sd=[sd;sd1];
end
%% JL1中聚类数量不足也作为散点提出
m=0;
figure
for i=1:size(RJL,2)
    points=RJL{i};
    scatter3(points(:,1),points(:,2),points(:,3))
    hold on
    if size(points,1)<20
        m=m+1;
        SDJ{m}=points;
        RJL{i}=[];
    end
end
for i=1:size(SDJ,2)
    points=SDJ{i};
    sd=[sd;points];
end
scatter3(sd(:,1),sd(:,2),sd(:,3),'black')
hold off
figure
m=0;
for i=1:size(RJL,2)
    points=RJL{i};
    if size(points,1)>0
        m=m+1;
        RRJL{m}=points;
        scatter3(points(:,1),points(:,2),points(:,3))
    end
    hold on
end
%% 去散点包围盒
figure
for i=1:size(RRJL,2)
    po=RRJL{i};
    k=boundary(po(:,1),po(:,2));
    plot(po(k,1),po(k,2))
    hold on
end
hold off
sd1=sd;
%sd1散点集合  RRJL已聚类集合
%% 进入第二段求离散点群类
clc
clearvars -except sd1 RRJL density
DATA=sd1(:,1:3);
ptCloud_in=pointCloud(DATA);
%% 解算各点密度
for i=1:size(DATA,1)
    [indices,dists]=findNeighborsInRadius(ptCloud_in,DATA(i,1:3),5);
    DATA(i,4)=size(dists,1);
end
DATA=sortrows(DATA,-4);
DATA=DATA(:,1:3);
%% 依次选取一点作为聚类中心
sd=[];
ptcloud=pointCloud(DATA(:,1:3));
for i=1:size(DATA,1)
    %选取密度最高的作为聚类中心
    center=DATA(i,1:3);
    [indices1,dists1]=findNeighborsInRadius(ptcloud,center,2);
    if size(dists1,1)<4
        sd=[sd;center];
    end
end
figure(33)
scatter3(DATA(:,1),DATA(:,2),DATA(:,3),'red')
hold on
scatter3(sd(:,1),sd(:,2),sd(:,3),'blue')
hold off
%% 去除密度不足点
ql=setdiff(DATA(:,1:3),sd,'rows');
figure(34)
scatter3(ql(:,1),ql(:,2),ql(:,3),'red')
ptcloud=pointCloud(ql(:,1:3));
[labels,numClusters]=pcsegdist(ptcloud,3);
figure(35)
pcshow(ptcloud.Location,labels,MarkerSize=70);
colormap(hsv(numClusters));
xlabel('X(m)');
ylabel('Y(m)');
zlabel('Z(m)');
%% 数据整理提出
figure(36)
A=cast(labels,'single');
ql=[ql,A];
ql=sortrows(ql,4);
for i=1:numClusters
    m=find(ql(:,4)==i);
    JL{i}=ql(m,1:3);
    p=double(ql(m,1:3));
    k=boundary(p(:,1),p(:,2));
    plot(p(k,1),p(k,2))
    hold on
end
scatter(sd(:,1),sd(:,2),"*")
%% 数据整合
m=0;
for i=1:size(JL,2)
    p=JL{i};
    if size(p,1)<8
        sd=[sd;p];
    else
        m=m+1;
        RJL{m}=p;
    end
end
qsd=[];
for i=1:size(sd,1)
    p1=sd(i,:);
    for j=1:size(RJL,2)
        p2=RJL{j};
        distance=pdist2(p1(:,1:2),p2(:,1:2));
        h1=p1(1,3);
        h2=p2(:,3);
        hz=[h2;h1];
        ave1=sum(h2)/size(h2,1);
        ave2=sum(hz)/size(hz,1);
        jfc1=sqrt(sum((h2-ave1).^2));
        jfc2=sqrt(sum((hz-ave2).^2));
        cc=abs(jfc2-jfc1)/jfc1;
        if min(distance)<=1
            qsd=[qsd;p1];
            p2=[p2;p1];
            RJL{j}=p2;
            i=0;
            j=1;
        end
    end
end
%qsd群散点
sd=setdiff(sd,qsd,'rows');
fsd=setdiff(DATA,sd,'rows');%非散点
figure(37)
% scatter3(sd(:,1),sd(:,2),sd(:,3))
scatter(sd(:,1),sd(:,2))
hold on
% scatter3(fsd(:,1),fsd(:,2),fsd(:,3))
scatter(fsd(:,1),fsd(:,2))
hold off
figure(38)
scatter3(sd(:,1),sd(:,2),sd(:,3))
hold on
scatter3(fsd(:,1),fsd(:,2),fsd(:,3))
hold off
figure(39)
for i=1:size(RJL,2)
    p=RJL{i};
    p=double(p);
    k=boundary(p(:,1),p(:,2));
    plot(p(k,1),p(k,2))
    hold on
end
i=0;
while true
    position1=[];
    i=i+1;
    if i>size(RJL,2)
        break
    end
    p1=double(RJL{i});
    if size(p1,1)==0
        continue
    end
    j=0;
    boundary1=boundary(p1(:,1),p1(:,2));
    position1=p1(boundary1,:);
    poly1=polyshape(position1(:,1),position1(:,2));
    h1=p1(:,3);
    ave1=sum(h1)/size(h1,1);
    gfz1=sqrt(sum((h1-ave1).^2));
    while true
        position2=[];
        j=j+1;
        if j>size(RJL,2)
            break
        end
        if j==i
            continue
        end
        p2=double(RJL{j});
        if size(p2,1)==0
            continue
        end
        boundary2=boundary(p2(:,1),p2(:,2));
        position2=p2(boundary2,:);
        poly2=polyshape(position2(:,1),position2(:,2));
        h2=p2(:,3);
        ave2=sum(h2)/size(h2,1);
        gfz2=sqrt(sum((h2-ave2).^2));
        %% 离散均方差判断
        if gfz1>0.1&&gfz2>0.1
            if intersect(poly1,poly2).NumRegions>0
                RJL{i}=[p1;p2];
                RJL{j}=[];
                j=0;
                continue
            end
        end
    end
end
m=0;
figure(40)
for i=1:size(RJL,2)
    p=RJL{i};
    if size(p,1)==0
        continue
    end
    m=m+1;
    RRJL2{m}=p;
    p=double(p);
    k=boundary(p(:,1),p(:,2));
    plot(p(k,1),p(k,2))
    hold on
end
figure(41)
for i=1:size(RRJL2,2)
    p=RRJL2{i};
    scatter3(p(:,1),p(:,2),p(:,3))
    hold on
end
for i=1:size(RRJL,2)
    p=RRJL{i};
    scatter3(p(:,1),p(:,2),p(:,3))
    hold on
end
%% 进入第三段对散点聚类和之前聚类结果判断拼接并实现散点归入聚类
clc
clearvars -except sd RRJL RRJL2 density
for i=1:size(RRJL,2)
    p1=double(RRJL{i});
    p1=p1(:,1:3);
    position1=[];
    j=0;
    boundary1=boundary(p1(:,1),p1(:,2));
    position1=p1(boundary1,:);
    poly1=polyshape(position1(:,1),position1(:,2));
    h1=p1(:,3);
    ave1=sum(h1)/size(h1,1);
    jfg1=sqrt(sum((h1-ave1).^2));
    while true
        position2=[];
        j=j+1;
        if j>size(RRJL2,2)
            break
        end
        p2=double(RRJL2{j});
        if size(p2,1)==0
            continue
        end
        boundary2=boundary(p2(:,1),p2(:,2));
        position2=p2(boundary2,:);
        poly2=polyshape(position2(:,1),position2(:,2));
        distance=pdist2(p1,p2);
        h2=p2(:,3);
        ave2=sum(h2)/size(h2,1);
        jfg2=sqrt(sum((h2-ave2).^2));
            if intersect(poly1,poly2).NumRegions>0&&size(p1,1)<200%&&min(min(distance))<1.5
                RJL{i}=[p1;p2];
                p1=[p1;p2];
                RRJL2{j}=[];
                continue
            else
                RJL{i}=p1;
            end
    end
end
cc=size(RJL,2);%规则聚类数
for i=1:size(RRJL2,2)
    p=RRJL2{i};
    if size(p,1)==0
        continue
    else
        cc=cc+1;
        RJL{cc}=p;
    end
end
figure(42)
for i=1:size(RJL,2)
    p=RJL{i};
    scatter3(p(:,1),p(:,2),p(:,3))
    hold on
end
scatter3(sd(:,1),sd(:,2),sd(:,3))
hold off
figure(52)
for i=1:size(RJL,2)
    p=RJL{i};
    scatter3(p(:,1),p(:,2),p(:,3),'black')
    hold on
end
scatter3(sd(:,1),sd(:,2),sd(:,3),'red')
hold off
%% 用冒泡算法对数组按个数大小排序
for i=1:size(RJL,2)-1
    for j=i+1:size(RJL,2)
        s11=RJL{i};
        s1=size(s11,1);
        s22=RJL{j};
        s2=size(s22,1);
        if s1<s2
            t1=RJL{i};
            RJL{i}=RJL{j};
            RJL{j}=t1;
        end
    end
end
%% 散点归拢
yjl=[];%已聚类散点
for i=1:size(sd,1)
    p1=sd(i,:);
    for j=1:size(RJL,2)
        p2=RJL{j};
        distance=pdist2(p1,p2);
        if min(distance)<2*density
            yjl=[yjl;p1];
            RJL{j}=[p2;p1];
        end
    end
end
sd=setdiff(sd,yjl,'rows');
num=0;
for i=1:size(RJL,2)
    num1=size(RJL{i},1);
    num=num+num1;
end
figure(43)
for i=1:size(RJL,2)
    p=RJL{i};
    p=double(p);
    k=boundary(p(:,1),p(:,2));
    plot(p(k,1),p(k,2),'LineWidth',2,'Color','black')
    hold on
    scatter(p(:,1),p(:,2),'*')
    hold on
end
hold off
figure(44)
for i=1:size(RJL,2)
    p=RJL{i};
    scatter3(p(:,1),p(:,2),p(:,3));
    hold on
end
scatter3(sd(:,1),sd(:,2),sd(:,3),'black')
hold off
figure(45)
for i=1:size(RJL,2)
    p=RJL{i};
    scatter3(p(:,1),p(:,2),p(:,3),'black');
    hold on
end
scatter3(sd(:,1),sd(:,2),sd(:,3),'red');
hold off
figure(46)
for i=1:size(RJL,2)
    p=RJL{i};
    p=double(p);
    k=boundary(p(:,1),p(:,2));
    plot(p(k,1),p(k,2),'LineWidth',2)
    hold on
end